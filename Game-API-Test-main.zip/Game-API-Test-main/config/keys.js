module.exports = {
  apiKey: process.env.API_KEY,
  MDKey: process.env.DB_KEY,
};
